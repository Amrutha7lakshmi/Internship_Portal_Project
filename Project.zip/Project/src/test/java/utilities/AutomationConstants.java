package utilities;

public class AutomationConstants {
	
	public static String expDash="Dashboard";
	public static String expname="arjun@example.com";
	public static String errMsg="Invalid username or password";
	public static String prjct1="testing";
	public static String prjct2="Postman";

}
